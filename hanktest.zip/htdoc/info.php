<?php

  phpinfo();

?>
