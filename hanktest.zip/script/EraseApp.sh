#!/bin/sh
rm -rf /var/www/html/*
