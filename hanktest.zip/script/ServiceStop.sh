#!/bin/sh
service httpd stop
